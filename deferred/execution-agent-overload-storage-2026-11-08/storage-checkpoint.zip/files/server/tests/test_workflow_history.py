from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import FrozenInstanceError, replace
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import sqlite3
import tempfile
import threading
import unittest
from unittest.mock import patch
from uuid import uuid4

from server.services.workflows import (
    LegacyLocator, SourceCompleteness, SourceInput, WorkflowStore,
)
from server.services.workflows import store as store_module
from server.services.workflows.errors import (
    WorkflowConflictError, WorkflowGenerationError, WorkflowIntegrityError,
    WorkflowNotFoundError, WorkflowSchemaError, WorkflowStorageError,
)
from server.services.workflows.models import encode_timestamp
from server.services.workflows.schema import SCHEMA_V1, SCHEMA_VERSION


@contextmanager
def database(path):
    connection = sqlite3.connect(path)
    try:
        with connection:
            yield connection
    finally:
        connection.close()


class WorkflowHistoryTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "workflows.db"
        self.now = datetime(2026, 11, 8, 12, tzinfo=timezone.utc)
        self.store = WorkflowStore(self.path, clock=lambda: self.now)
        self.history = self.store.history
        self.source = SourceInput(b"exact payload", "text/plain; charset=utf-8", "tool_adapter")
        self.raw = b'<user_message timestamp="2026-11-08 12:00:00">exact payload</user_message>\r\n'
        self.locator = LegacyLocator("conversation/poke_conversation.log", sha256(self.raw).hexdigest(),
                                     0, 1, 0, len(self.raw), "2026-11-08 12:00:00")

    def append(self, **kwargs):
        return self.history.append_event(**{"scope": "local", "stream_key": "conversation:main", "kind": "tool_result",
                                             "source": self.source, "idempotency_key": "capture-1", **kwargs})

    def legacy(self, **kwargs):
        return self.history.append_legacy_event(**{"scope": "local", "stream_key": "legacy:conversation",
            "kind": "user_message", "source": replace(self.source, completeness=SourceCompleteness.LEGACY_UNKNOWN),
            "locator": self.locator, "raw_record": self.raw, **kwargs})

    def counts(self):
        with database(self.path) as connection:
            return {table: connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    for table in ("source_objects", "event_streams", "events", "legacy_source_files", "legacy_event_refs")}

    def match(self, query, *, scope="local"):
        with self.store._transaction() as connection:
            return [row[0] for row in connection.execute("""SELECT e.event_id FROM event_search_fts f JOIN events e ON f.rowid=e.rowid
                WHERE event_search_fts MATCH ? AND e.scope=? AND e.generation_id=? ORDER BY e.sequence""",
                (query, scope, str(self.store.generation_id)))]

    def test_large_binary_source_round_trips_exactly_through_bounded_pages(self):
        content = b"prefix\x00" + b"x" * 80000 + "important Café fact 🦉".encode() + b"y" * 80000
        event = self.append(source=SourceInput(content, "application/octet-stream", "tool_adapter"), occurred_at=self.now)
        metadata = self.history.get_source(event.source_id, scope="local")
        self.assertEqual(metadata.content_sha256, sha256(content).hexdigest())
        self.assertEqual(metadata.size_bytes, len(content))
        self.assertEqual(metadata.completeness, SourceCompleteness.COMPLETE)
        self.assertFalse(hasattr(metadata, "content"))
        parts, offset = [], 0
        while True:
            page = self.history.read_source(event.source_id, scope="local", offset=offset, limit=16383)
            self.assertLessEqual(len(page.content), 16383)
            parts.append(page.content)
            if page.next_offset is None:
                break
            offset = page.next_offset
        self.assertEqual(b"".join(parts), content)
        self.assertEqual(self.history.read_source(event.source_id, scope="local", offset=len(content)).content, b"")
        self.assertEqual(event.occurred_at, self.now)
        with self.assertRaises(FrozenInstanceError):
            event.kind = "changed"

    def test_restart_and_summary_changes_preserve_event_and_source_identity(self):
        workflow = self.store.create(scope="local", display_name="Alice lunch")
        event = self.append(workflow_id=workflow.workflow_id, run_id="run-1", turn_id="turn-1")
        self.assertEqual(self.store.get(workflow.workflow_id, scope="local"), workflow)
        self.store.update(workflow.workflow_id, scope="local", expected_revision=1,
                          summary="new short summary", display_name="Alice birthday lunch")
        reopened = WorkflowStore(self.path).history
        self.assertEqual(reopened.get_event(event.event_id, scope="local"), event)
        self.assertEqual(reopened.read_source(event.source_id, scope="local").content, self.source.content)
        self.assertEqual(reopened.get_source(event.source_id, scope="local").recorded_at, self.now)

    def test_capture_replay_is_idempotent_and_changed_content_or_bindings_conflict(self):
        event = self.append(search_text="sushi")
        self.assertEqual(self.append(search_text="sushi"), event)
        before = self.counts()
        for change in ({"source": replace(self.source, content=b"different")}, {"kind": "different"},
                       {"stream_key": "other"}, {"run_id": "new-run"}, {"occurred_at": self.now},
                       {"search_text": "different"}, {"source": replace(self.source, provenance="different")}):
            with self.assertRaises(WorkflowConflictError):
                self.append(**{"search_text": "sushi", **change})
        self.assertEqual(self.counts(), before)
        self.assertEqual(self.append(idempotency_key="capture-2").sequence, 1)
        self.assertEqual(self.match("sushi"), [str(event.event_id)])

    def test_identical_bytes_from_distinct_captures_keep_separate_provenance(self):
        first = self.append()
        second = self.append(idempotency_key="capture-2", source=replace(self.source, provenance="other_adapter"))
        self.assertNotEqual(first.source_id, second.source_id)
        self.assertNotEqual(first.event_id, second.event_id)
        self.assertEqual(self.history.get_source(first.source_id, scope="local").content_sha256,
                         self.history.get_source(second.source_id, scope="local").content_sha256)

    def test_scopes_qualify_events_sources_streams_and_idempotency_keys(self):
        first = self.append()
        second = self.append(scope="other")
        self.assertNotEqual(first.event_id, second.event_id)
        self.assertEqual(first.sequence, second.sequence)
        self.assertIsNone(self.history.get_event(first.event_id, scope="other"))
        self.assertIsNone(self.history.get_source(first.source_id, scope="other"))
        self.assertIsNone(self.history.read_source(first.source_id, scope="other"))
        self.assertEqual(self.history.list_events(scope="other", stream_key=second.stream_key), [second])
        local = self.store.create(scope="local", display_name="local owner")
        with self.assertRaises(WorkflowNotFoundError):
            self.append(scope="other", idempotency_key="invalid", workflow_id=local.workflow_id)

    def test_stream_owner_binding_cannot_change_between_events(self):
        first = self.store.create(scope="local", display_name="Alice lunch")
        second = self.store.create(scope="local", display_name="Alice contract")
        event = self.append(workflow_id=first.workflow_id, conversation_id="main")
        before = self.counts()
        for binding in ({"workflow_id": second.workflow_id, "conversation_id": "main"},
                        {"workflow_id": first.workflow_id, "conversation_id": "different"}):
            with self.assertRaises(WorkflowConflictError):
                self.append(idempotency_key="next", **binding)
        self.assertEqual(self.counts(), before)
        self.assertEqual(self.history.get_event(event.event_id, scope="local"), event)

    def test_paging_preserves_sequence_and_rejects_invalid_bounds(self):
        events = [self.append(idempotency_key=f"capture-{index}") for index in range(5)]
        first = self.history.list_events(scope="local", stream_key=events[0].stream_key, limit=2)
        second = self.history.list_events(scope="local", stream_key=events[0].stream_key, limit=2, after_sequence=first[-1].sequence)
        last = self.history.list_events(scope="local", stream_key=events[0].stream_key, after_sequence=second[-1].sequence)
        self.assertEqual(first + second + last, events)
        for kwargs in ({"limit": 0}, {"limit": 101}, {"limit": True}, {"after_sequence": -2}, {"after_sequence": 2**100}):
            with self.assertRaises(ValueError):
                self.history.list_events(scope="local", stream_key=events[0].stream_key, **kwargs)
        for kwargs in ({"limit": 0}, {"limit": 65537}, {"offset": -1}, {"offset": True},
                       {"offset": 2**100}, {"offset": len(self.source.content) + 1}):
            with self.assertRaises(ValueError):
                self.history.read_source(events[0].source_id, scope="local", **kwargs)

    def test_empty_source_is_preserved_as_observed_empty_content(self):
        event = self.append(source=replace(self.source, content=b""))
        page = self.history.read_source(event.source_id, scope="local")
        self.assertEqual(page.content, b"")
        self.assertEqual(page.source.size_bytes, 0)
        self.assertEqual(page.source.content_sha256, sha256(b"").hexdigest())
        self.assertIsNone(page.next_offset)

    def test_legacy_mapping_replays_after_restart_and_preserves_raw_record(self):
        event = self.legacy()
        reference = self.history.resolve_legacy(self.locator.source_path, 0, scope="local")
        reopened = WorkflowStore(self.path).history
        self.assertEqual(reference.event_id, event.event_id)
        self.assertEqual(reference.locator, self.locator)
        self.assertEqual(reopened.resolve_legacy(self.locator.source_path, 0, scope="local"), reference)
        self.assertEqual(reopened.append_legacy_event(scope="local", stream_key="legacy:conversation", kind="user_message",
                         source=replace(self.source, completeness=SourceCompleteness.LEGACY_UNKNOWN),
                         locator=self.locator, raw_record=self.raw), event)
        self.assertEqual(self.history.read_source(reference.raw_source_id, scope="local").content, self.raw)
        self.assertEqual(self.history.get_source(event.source_id, scope="local").completeness, SourceCompleteness.LEGACY_UNKNOWN)
        self.assertEqual(self.history.get_source(reference.raw_source_id, scope="local").completeness, SourceCompleteness.COMPLETE)
        self.assertIsNone(event.occurred_at)  # The original timestamp has no timezone.
        self.assertEqual(self.counts()["source_objects"], 2)

    def test_changed_legacy_snapshot_locator_or_content_never_silently_reimports(self):
        event = self.legacy()
        before = self.counts()
        for change in ({"source": replace(self.source, content=b"changed", completeness="legacy_unknown")},
                       {"locator": replace(self.locator, byte_offset=5)},
                       {"locator": replace(self.locator, source_sha256="f" * 64)},
                       {"raw_record": b"X" * len(self.raw)},
                       {"locator": replace(self.locator, legacy_index=1, source_sha256="e" * 64)},
                       {"locator": replace(self.locator, legacy_index=1), "stream_key": "different"}):
            with self.assertRaises(WorkflowConflictError):
                self.legacy(**change)
        self.assertEqual(self.counts(), before)
        self.assertEqual(self.history.resolve_legacy(self.locator.source_path, 0, scope="local").event_id, event.event_id)
        following = self.legacy(locator=replace(self.locator, legacy_index=1, line=2, byte_offset=len(self.raw)))
        self.assertEqual(following.sequence, 1)

    def test_legacy_aliases_are_scoped_and_do_not_collide_with_capture_keys(self):
        first = self.legacy()
        other = self.legacy(scope="other")
        capture = self.append(idempotency_key="legacy:" + self.locator.source_path)
        self.assertEqual(self.history.resolve_legacy(self.locator.source_path, 0, scope="other").event_id, other.event_id)
        self.assertNotEqual(first.event_id, capture.event_id)
        self.assertIsNone(self.history.resolve_legacy(self.locator.source_path, 99, scope="local"))
        self.assertIsNone(self.history.resolve_legacy(self.locator.source_path, 0, scope="absent"))

    def test_legacy_mapping_failure_rolls_back_sources_stream_event_and_index(self):
        with database(self.path) as connection:
            connection.execute("""CREATE TRIGGER reject_legacy BEFORE INSERT ON legacy_event_refs
                BEGIN SELECT RAISE(ABORT, 'injected mapping failure'); END""")
        with self.assertRaises(WorkflowIntegrityError):
            self.legacy(search_text="sushi")
        self.assertTrue(all(count == 0 for count in self.counts().values()))
        self.assertEqual(self.match("sushi"), [])
        with database(self.path) as connection:
            connection.execute("DROP TRIGGER reject_legacy")
        self.assertEqual(self.legacy(search_text="sushi").sequence, 0)

    def test_event_write_failure_preserves_previous_history_and_search(self):
        old = self.append(search_text="sushi")
        before = self.counts()
        with database(self.path) as connection:
            connection.execute("""CREATE TRIGGER reject_event AFTER INSERT ON events
                BEGIN SELECT RAISE(ABORT, 'injected event failure'); END""")
        with self.assertRaises(WorkflowIntegrityError):
            self.append(idempotency_key="next", search_text="tapas")
        self.assertEqual(self.counts(), before)
        self.assertEqual(self.match("tapas"), [])
        self.assertEqual(self.match("sushi"), [str(old.event_id)])

    def test_rebuild_restores_fts_without_changing_sources_or_events(self):
        event = self.append(search_text="sushi")
        with self.store._transaction(write=True) as connection:
            connection.execute("INSERT INTO event_search_fts(event_search_fts) VALUES('delete-all')")
        self.assertEqual(self.match("sushi"), [])
        self.assertEqual(self.history.rebuild_event_index(), 1)
        self.assertEqual(self.match("sushi"), [str(event.event_id)])
        self.assertEqual(self.history.get_event(event.event_id, scope="local"), event)
        self.assertEqual(self.history.read_source(event.source_id, scope="local").content, self.source.content)

    def test_history_tables_reject_updates_deletes_and_replace(self):
        self.legacy()
        before = self.counts()
        for table in before:
            for sql in (f"UPDATE {table} SET scope=scope", f"DELETE FROM {table}",
                        f"INSERT OR REPLACE INTO {table} SELECT * FROM {table}"):
                with self.assertRaises(WorkflowIntegrityError):
                    with self.store._connection() as connection:
                        connection.execute(sql)
        self.assertEqual(self.counts(), before)

    def test_foreign_keys_reject_cross_scope_source_bindings(self):
        first = self.append()
        self.append(scope="other")
        with self.assertRaises(WorkflowIntegrityError):
            with self.store._connection() as connection:
                connection.execute("""INSERT INTO events SELECT ?, 'other', generation_id, stream_key, 1, kind,
                    source_id, run_id, turn_id, occurred_at, recorded_at, 'invalid', request_sha256, search_text
                    FROM events WHERE event_id=?""", (str(uuid4()), str(first.event_id)))
        self.assertEqual(self.counts()["events"], 2)

    def test_concurrent_replays_share_identity_and_distinct_appends_have_unique_sequence(self):
        stores = [self.store, WorkflowStore(self.path)]
        def run(keys):
            barrier = threading.Barrier(2)
            def capture(item):
                store, key = item
                barrier.wait(timeout=2)
                return store.history.append_event(scope="local", stream_key="concurrent", kind="result",
                                                   source=self.source, idempotency_key=key)
            with ThreadPoolExecutor(max_workers=2) as executor:
                return list(executor.map(capture, zip(stores, keys)))
        replay = run(["same", "same"])
        self.assertEqual(replay[0], replay[1])
        distinct = run(["second", "third"])
        self.assertEqual({event.sequence for event in distinct}, {1, 2})
        self.assertEqual(self.counts()["source_objects"], 3)

    def test_invalid_legacy_locations_and_unqualified_content_are_rejected(self):
        for path in ("../outside.log", "/absolute.log", "C:/absolute.log", "a\\b.log", "./a.log", "a//b.log", "."):
            with self.assertRaises(ValueError):
                replace(self.locator, source_path=path)
        for change in ({"legacy_index": True}, {"byte_length": 0}, {"line": 0}, {"source_sha256": "unknown"}):
            with self.assertRaises(ValueError):
                replace(self.locator, **change)
        for change in ({"source": self.source}, {"raw_record": b"wrong length"}):
            with self.assertRaises(ValueError):
                self.legacy(**change)
        with self.assertRaises(ValueError):
            replace(self.source, content=bytearray(b"mutable"))
        event = self.legacy(source=replace(self.source, completeness="known_truncated"))
        self.assertEqual(self.history.get_source(event.source_id, scope="local").completeness, SourceCompleteness.KNOWN_TRUNCATED)
        with self.assertRaises(ValueError):
            replace(event, event_id=None)

    def test_missing_corrupt_or_changed_generation_is_never_an_empty_success(self):
        identifier = uuid4()
        with database(self.path) as connection:
            connection.execute("UPDATE store_state SET generation_id=?", (str(uuid4()),))
        with self.assertRaises(WorkflowGenerationError):
            self.history.get_source(identifier, scope="local")
        with self.assertRaises(WorkflowGenerationError):
            self.append()
        self.path.unlink()
        with self.assertRaises(WorkflowStorageError):
            self.history.get_event(identifier, scope="local")
        self.assertFalse(self.path.exists())
        self.path.write_bytes(b"corrupt database")
        with self.assertRaises(WorkflowStorageError):
            self.history.get_source(identifier, scope="local")

    def test_invalid_stored_metadata_is_an_integrity_error(self):
        event = self.append()
        with database(self.path) as connection:
            connection.execute("DROP TRIGGER source_objects_immutable_update")
            connection.execute("UPDATE source_objects SET recorded_at='invalid'")
        with self.assertRaises(WorkflowIntegrityError):
            self.history.get_source(event.source_id, scope="local")
        with database(self.path) as connection:
            connection.execute("DROP TRIGGER events_immutable_update")
            connection.execute("UPDATE events SET occurred_at='invalid'")
        with self.assertRaises(WorkflowIntegrityError):
            self.history.get_event(event.event_id, scope="local")
        with self.assertRaises(WorkflowSchemaError):
            WorkflowStore(self.path)


class WorkflowHistoryUpgradeTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.path = Path(directory.name) / "v1.db"
        self.generation, self.workflow = str(uuid4()), str(uuid4())
        self.stamp = encode_timestamp(datetime(2026, 11, 8, tzinfo=timezone.utc))
        with database(self.path) as connection:
            for statement in SCHEMA_V1:
                connection.execute(statement)
            connection.execute("INSERT INTO store_state VALUES(1, ?)", (self.generation,))
            connection.execute("INSERT INTO schema_migrations VALUES(1, ?)", (self.stamp,))
            connection.execute("INSERT INTO workflows VALUES(?, 'local', ?, 'Alice lunch', 'sushi', '', NULL, ?, ?, NULL, 3)",
                               (self.workflow, self.generation, self.stamp, self.stamp))
            connection.execute("INSERT INTO workflow_aliases VALUES('local', ?, 'Old lunch alias', ?, ?)",
                               (self.generation, self.workflow, self.stamp))
            connection.execute("INSERT INTO workflow_search_documents(workflow_id, scope, generation_id, document) VALUES(?, 'local', ?, 'sushi')",
                               (self.workflow, self.generation))
            connection.execute("PRAGMA user_version=1")

    def test_v1_upgrade_preserves_workflow_generation_aliases_and_search(self):
        store = WorkflowStore(self.path)
        self.assertEqual(str(store.generation_id), self.generation)
        workflow = store.get_by_alias("Old lunch alias", scope="local")
        self.assertEqual(str(workflow.workflow_id), self.workflow)
        self.assertEqual(workflow.revision, 3)
        self.assertIsNone(workflow.status)
        with database(self.path) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], SCHEMA_VERSION)
            self.assertEqual(connection.execute("SELECT version FROM schema_migrations ORDER BY version").fetchall(), [(1,), (2,)])
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM workflow_search_fts WHERE workflow_search_fts MATCH 'sushi'").fetchone()[0], 1)
        event = store.history.append_event(scope="local", stream_key="workflow:" + self.workflow, kind="result",
                                          workflow_id=self.workflow, source=SourceInput(b"source", "text/plain", "adapter"), idempotency_key="1")
        self.assertEqual(WorkflowStore(self.path).history.get_event(event.event_id, scope="local"), event)

    def test_failed_upgrade_rolls_back_ddl_version_and_migration_record_then_can_resume(self):
        with patch.object(store_module, "SCHEMA_V2", (*store_module.SCHEMA_V2, "INVALID SQL")):
            with self.assertRaises(WorkflowStorageError):
                WorkflowStore(self.path)
        with database(self.path) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 1)
            self.assertEqual(connection.execute("SELECT version FROM schema_migrations").fetchall(), [(1,)])
            self.assertIsNone(connection.execute("SELECT name FROM sqlite_master WHERE name='source_objects'").fetchone())
            self.assertEqual(connection.execute("SELECT workflow_id, revision FROM workflows").fetchall(), [(self.workflow, 3)])
        self.assertEqual(str(WorkflowStore(self.path).generation_id), self.generation)

    def test_incomplete_v1_is_rejected_before_new_schema_is_written(self):
        with database(self.path) as connection:
            connection.execute("DROP TRIGGER workflow_document_update")
        with self.assertRaises(WorkflowSchemaError):
            WorkflowStore(self.path)
        with database(self.path) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 1)
            self.assertIsNone(connection.execute("SELECT name FROM sqlite_master WHERE name='source_objects'").fetchone())

    def test_v2_failure_on_empty_database_rolls_back_both_schema_versions(self):
        path = self.path.parent / "empty.db"
        with patch.object(store_module, "SCHEMA_V2", (*store_module.SCHEMA_V2, "INVALID SQL")):
            with self.assertRaises(WorkflowStorageError):
                WorkflowStore(path)
        with database(path) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 0)
            self.assertEqual(connection.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall(), [])
        WorkflowStore(path)


if __name__ == "__main__":
    unittest.main()
