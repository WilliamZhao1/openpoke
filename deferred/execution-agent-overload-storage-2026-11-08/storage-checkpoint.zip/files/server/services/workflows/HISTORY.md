# Immutable source and event storage

This is the third slice of Phase 1. `WorkflowStore.history` saves source bytes,
event envelopes, and exact legacy-entry mappings in the same SQLite database.
It is backend persistence; the app still uses its existing stores. No importer,
model-visible recall tool, execution handler, or history-clear operation is
enabled by this change.

## Motivation and old behavior

The original worker and conversation stores use text logs and parsed-entry
positions. Worker tools record shortened responses. A summary can omit details,
and a legacy position alone does not provide a durable content reference.
The previous storage slice gave workflows stable IDs, while the dry-run supplied
hashes and locations without saving source content or event mappings.

This slice preserves exact supplied bytes behind immutable source UUIDs. Events
refer to those sources rather than embedding a preview. A scoped legacy position
resolves to the same event UUID after restart. Capturing a summary later does
not replace earlier content.

## Schema and design

Schema version 2 adds:

| Record | Contract |
| --- | --- |
| `source_objects` | UUID, scope/generation, exact BLOB, SHA-256, byte size, media type, provenance, completeness, and capture timestamp. |
| `event_streams` | Stable backend key within scope/generation, immutable workflow/conversation binding, and capture timestamp. |
| `events` | UUID, stream sequence, kind, source UUID, optional run/turn IDs and occurrence timestamp, capture timestamp, replay identity, and indexed search text. Workflow/conversation context comes from the bound stream. |
| `legacy_source_files` | One original file fingerprint and stream binding per scoped path/generation. |
| `legacy_event_refs` | Original path/index to event/raw-source UUIDs, line, byte offset/length, and original timestamp text. |
| `event_search_fts` | Rebuildable FTS5 projection of explicitly supplied event search text. |

Frozen models and SQL update/delete guards prevent ordinary history edits.
Store connections enable recursive triggers so `INSERT OR REPLACE` cannot bypass
the delete guards. These guards do not replace future explicit lifecycle/delete
handling or protect against an external writer dropping schema constraints.

Capturing an event commits its stream, source, event, FTS entry, and optional
legacy file/mapping/raw source together. Failure rolls back the whole capture.
Content hashing happens before acquiring the writer lock. Writes reuse the
store's short transactions, bounded busy handling, foreign keys, and generation
check. Unique sequence constraints plus serialized transactions keep concurrent
appends ordered; sequences start at zero within each stream.

New captures use a backend-owned idempotency key. Replaying identical content
and bindings returns the original event/source IDs without allocating another
sequence. Reusing the key with changed content or bindings raises
`WorkflowConflictError`. Identical bytes from different captures retain separate
IDs and provenance. This prevents duplicate local event capture; it does not
establish exactly-once email sending or request admission.

## Capture and recovery example

Use these APIs inside the configured backend or isolated test environment.
Configure `OPENPOKE_DATA_DIR` before importing `server`; its existing application
imports initialize legacy services. Constructing a `WorkflowStore` explicitly
opens or upgrades that database.

```python
from server.services.workflows import SourceInput, WorkflowStore

store = WorkflowStore()
workflow = store.create(scope="local", display_name="Alice lunch")
capture = dict(
    scope="local",
    stream_key=f"workflow:{workflow.workflow_id}",
    workflow_id=workflow.workflow_id,
    kind="tool_result",
    idempotency_key="backend-capture-123",
    source=SourceInput(
        b"Exact original result, including details omitted by a summary.",
        "text/plain; charset=utf-8",
        "tool_adapter",
    ),
    search_text="Alice lunch restaurant options",
)
event = store.history.append_event(**capture)
assert store.history.append_event(**capture) == event
page = store.history.read_source(event.source_id, scope="local", limit=32)
assert page.next_offset == 32
```

`get_event` returns an envelope and `get_source` returns metadata without loading
the full content. `list_events` pages by stream sequence, with limits of 1–100
and an `after_sequence` cursor. `read_source` returns exact byte pages, default
8,192 and maximum 65,536 bytes, with an explicit next offset and source metadata.
Byte pages may split UTF-8 characters; join bytes before decoding text. The stored
SHA-256 lets readers verify assembled content. Empty content returns a page with
`b""`; a genuinely missing or out-of-scope reference returns `None`. Storage
failures still raise explicit errors.

`search_text` is a caller-supplied retrieval projection, not the source content
or an authoritative outcome. The default is empty. `rebuild_event_index()`
recreates FTS5 from stored event text without modifying source/event IDs. Public
query normalization, ranking, and tool budgets remain later work.

## Legacy references and completeness

`append_legacy_event` accepts a validated `LegacyLocator`, decoded payload bytes
in a `SourceInput`, and the exact raw record bytes. Its caller must already have
verified the file fingerprint and reconciled ownership. This primitive does not
read files, prove the supplied offset belongs to a snapshot, or resolve a slug
collision. Paths must be canonical relative POSIX paths.

`resolve_legacy("conversation/poke_conversation.log", 42, scope="local")` returns
the original locator, stable event UUID, and raw-source UUID. Thus a later
summary importer can map `last_index=42` without using an array position as the
new event ID. It can recover both decoded payload and raw record, including
escaping and line endings. Event sequence is append order; the legacy index is
retained separately, so both references survive even if import order differs.

A path is bound to one frozen file fingerprint and one stream in a
scope/generation. Replaying an unchanged entry returns its existing event;
changing the bytes, locator, fingerprint, or owner conflicts. This deliberately
rejects importing a changed/extended file as another copy of the original
snapshot. Future apply mode must freeze and validate inputs before importing.

Source completeness is explicit: `complete`, `legacy_unknown`, or
`known_truncated`. Legacy decoded payloads must use a qualified state. Exact raw
record capture is complete relative to the saved file; that does not restore
tool output lost before the legacy writer saved it. Normal capture preserves
all supplied bytes but depends on its caller accurately qualifying upstream
content. There is no automatic truncation.

`recorded_at` is the UTC capture time. `occurred_at` is optional and must be
timezone-aware when supplied. Legacy capture leaves it unknown and preserves
the original timestamp text in the locator. It does not guess a timezone or
present import time as the historical occurrence time.

## Upgrade, validation, and remaining work

Explicit store construction validates a recognized version-1 schema before
upgrading it to version 2. DDL, migration records, and `user_version` commit
together. A failed upgrade leaves version 1 usable for a retry; workflows,
aliases, revisions, generation, and existing workflow FTS data remain intact.
Fresh initialization rolls back both versions if either fails. Reopening
version 2 does not repeat migrations. Incomplete or newer schemas are rejected.

`python server/tests/run_tests.py` passes all 143 tests, including 24 new history
tests. Coverage includes exact large/binary/empty content, bounded paging,
restart/rename/summary persistence, qualified legacy content and raw bytes,
replay conflicts, source/owner boundaries, concurrent appends, SQL immutability,
foreign keys, index rebuild and rollback, corrupt/missing storage, generation
changes, and successful/failed schema upgrades. All storage is temporary; no
live model or email calls run.

The next slice is a consistent backup/snapshot bundle with a validation
manifest. Resumable migration apply, durable workflow-import mappings, trigger
backfill, summary import, activity records/cards, authoritative adapters, and
startup gating still follow. Appending history here does not advance workflow
state or revisions; later activity/projection writes must do that atomically
with their confirmed state changes. These records do not authorize dispatch,
approve content, or provide lifecycle deletion/clear behavior.
