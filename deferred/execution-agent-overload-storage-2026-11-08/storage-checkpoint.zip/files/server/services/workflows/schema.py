"""Transactional schema migrations. Legacy file import is a separate operation."""

SCHEMA_VERSION = 2

# Execute individual statements inside the caller's transaction. executescript()
# may commit a pending transaction before running the script.
SCHEMA_V1 = (
    """CREATE TABLE schema_migrations (
        version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL
    )""",
    """CREATE TABLE store_state (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        generation_id TEXT NOT NULL UNIQUE CHECK (length(generation_id) = 36)
    )""",
    """CREATE TABLE workflows (
        workflow_id TEXT PRIMARY KEY NOT NULL CHECK (length(workflow_id) = 36),
        scope TEXT NOT NULL CHECK (length(trim(scope)) > 0),
        generation_id TEXT NOT NULL REFERENCES store_state(generation_id),
        display_name TEXT NOT NULL CHECK (length(trim(display_name)) > 0),
        purpose TEXT NOT NULL DEFAULT '', summary TEXT NOT NULL DEFAULT '',
        status TEXT CHECK (status IN ('open', 'waiting_for_approval',
            'waiting_for_external_event', 'completed', 'cancelled')),
        created_at TEXT NOT NULL, last_activity_at TEXT NOT NULL,
        archived_at TEXT,
        revision INTEGER NOT NULL CHECK (typeof(revision) = 'integer' AND revision >= 1),
        UNIQUE (workflow_id, scope, generation_id),
        CHECK (last_activity_at >= created_at)
    )""",
    """CREATE INDEX workflow_scope_page
        ON workflows(scope, generation_id, workflow_id)""",
    """CREATE TABLE workflow_aliases (
        scope TEXT NOT NULL, generation_id TEXT NOT NULL,
        alias TEXT COLLATE BINARY NOT NULL, workflow_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        PRIMARY KEY (scope, generation_id, alias),
        FOREIGN KEY (workflow_id, scope, generation_id)
            REFERENCES workflows(workflow_id, scope, generation_id) ON DELETE CASCADE
    )""",
    """CREATE INDEX workflow_alias_owner
        ON workflow_aliases(workflow_id, scope, generation_id)""",
    """CREATE TABLE workflow_search_documents (
        doc_id INTEGER PRIMARY KEY, workflow_id TEXT NOT NULL UNIQUE,
        scope TEXT NOT NULL, generation_id TEXT NOT NULL, document TEXT NOT NULL,
        FOREIGN KEY (workflow_id, scope, generation_id)
            REFERENCES workflows(workflow_id, scope, generation_id) ON DELETE CASCADE
    )""",
    """CREATE INDEX workflow_document_scope
        ON workflow_search_documents(scope, generation_id, workflow_id)""",
    """CREATE VIRTUAL TABLE workflow_search_fts USING fts5(
        document, content='workflow_search_documents', content_rowid='doc_id'
    )""",
    """CREATE TRIGGER workflow_document_insert AFTER INSERT ON workflow_search_documents BEGIN
        INSERT INTO workflow_search_fts(rowid, document) VALUES(new.doc_id, new.document);
    END""",
    """CREATE TRIGGER workflow_document_delete AFTER DELETE ON workflow_search_documents BEGIN
        INSERT INTO workflow_search_fts(workflow_search_fts, rowid, document)
            VALUES('delete', old.doc_id, old.document);
    END""",
    """CREATE TRIGGER workflow_document_update AFTER UPDATE ON workflow_search_documents BEGIN
        INSERT INTO workflow_search_fts(workflow_search_fts, rowid, document)
            VALUES('delete', old.doc_id, old.document);
        INSERT INTO workflow_search_fts(rowid, document) VALUES(new.doc_id, new.document);
    END""",
)

REQUIRED_V1_TABLES = {
    "schema_migrations", "store_state", "workflows", "workflow_aliases",
    "workflow_search_documents", "workflow_search_fts",
}
REQUIRED_V1_TRIGGERS = {
    "workflow_document_insert", "workflow_document_delete", "workflow_document_update",
}

# Source bytes are canonical. Search text is an explicitly supplied projection.
SCHEMA_V2 = (
    """CREATE TABLE source_objects (
        source_id TEXT PRIMARY KEY NOT NULL CHECK (length(source_id) = 36),
        scope TEXT NOT NULL CHECK (length(trim(scope)) > 0),
        generation_id TEXT NOT NULL REFERENCES store_state(generation_id),
        content BLOB NOT NULL CHECK (typeof(content) = 'blob'),
        content_sha256 TEXT NOT NULL CHECK (length(content_sha256) = 64),
        size_bytes INTEGER NOT NULL CHECK (size_bytes >= 0 AND size_bytes = length(content)),
        media_type TEXT NOT NULL CHECK (length(trim(media_type)) > 0),
        provenance TEXT NOT NULL CHECK (length(trim(provenance)) > 0),
        completeness TEXT NOT NULL CHECK (completeness IN ('complete', 'legacy_unknown', 'known_truncated')),
        recorded_at TEXT NOT NULL,
        UNIQUE (source_id, scope, generation_id)
    )""",
    """CREATE TABLE event_streams (
        stream_key TEXT NOT NULL CHECK (length(trim(stream_key)) > 0),
        scope TEXT NOT NULL CHECK (length(trim(scope)) > 0),
        generation_id TEXT NOT NULL REFERENCES store_state(generation_id),
        workflow_id TEXT, conversation_id TEXT, recorded_at TEXT NOT NULL,
        PRIMARY KEY (scope, generation_id, stream_key),
        FOREIGN KEY (workflow_id, scope, generation_id)
            REFERENCES workflows(workflow_id, scope, generation_id)
    )""",
    """CREATE TABLE events (
        event_id TEXT PRIMARY KEY NOT NULL CHECK (length(event_id) = 36),
        scope TEXT NOT NULL, generation_id TEXT NOT NULL, stream_key TEXT NOT NULL,
        sequence INTEGER NOT NULL CHECK (typeof(sequence) = 'integer' AND sequence >= 0),
        kind TEXT NOT NULL CHECK (length(trim(kind)) > 0), source_id TEXT NOT NULL,
        run_id TEXT, turn_id TEXT, occurred_at TEXT, recorded_at TEXT NOT NULL,
        write_key TEXT NOT NULL, request_sha256 TEXT NOT NULL CHECK (length(request_sha256) = 64),
        search_text TEXT NOT NULL,
        UNIQUE (event_id, scope, generation_id),
        UNIQUE (scope, generation_id, stream_key, sequence),
        UNIQUE (scope, generation_id, write_key),
        FOREIGN KEY (scope, generation_id, stream_key)
            REFERENCES event_streams(scope, generation_id, stream_key),
        FOREIGN KEY (source_id, scope, generation_id)
            REFERENCES source_objects(source_id, scope, generation_id)
    )""",
    """CREATE TABLE legacy_source_files (
        scope TEXT NOT NULL, generation_id TEXT NOT NULL REFERENCES store_state(generation_id),
        source_path TEXT NOT NULL, source_sha256 TEXT NOT NULL CHECK (length(source_sha256) = 64),
        stream_key TEXT NOT NULL, recorded_at TEXT NOT NULL,
        PRIMARY KEY (scope, generation_id, source_path),
        FOREIGN KEY (scope, generation_id, stream_key) REFERENCES event_streams(scope, generation_id, stream_key)
    )""",
    """CREATE TABLE legacy_event_refs (
        scope TEXT NOT NULL, generation_id TEXT NOT NULL, source_path TEXT NOT NULL,
        legacy_index INTEGER NOT NULL CHECK (typeof(legacy_index) = 'integer' AND legacy_index >= 0),
        event_id TEXT NOT NULL UNIQUE, raw_source_id TEXT NOT NULL,
        line INTEGER NOT NULL CHECK (line >= 1), byte_offset INTEGER NOT NULL CHECK (byte_offset >= 0),
        byte_length INTEGER NOT NULL CHECK (byte_length > 0), timestamp_text TEXT,
        PRIMARY KEY (scope, generation_id, source_path, legacy_index),
        FOREIGN KEY (scope, generation_id, source_path)
            REFERENCES legacy_source_files(scope, generation_id, source_path),
        FOREIGN KEY (event_id, scope, generation_id) REFERENCES events(event_id, scope, generation_id),
        FOREIGN KEY (raw_source_id, scope, generation_id)
            REFERENCES source_objects(source_id, scope, generation_id)
    )""",
    """CREATE VIRTUAL TABLE event_search_fts USING fts5(
        search_text, content='events', content_rowid='rowid'
    )""",
    """CREATE TRIGGER event_search_insert AFTER INSERT ON events BEGIN
        INSERT INTO event_search_fts(rowid, search_text) VALUES(new.rowid, new.search_text);
    END""",
    *(
        f"""CREATE TRIGGER {table}_immutable_{action.lower()} BEFORE {action} ON {table}
            BEGIN SELECT RAISE(ABORT, 'Immutable history record'); END"""
        for table in ("source_objects", "event_streams", "events", "legacy_source_files", "legacy_event_refs")
        for action in ("UPDATE", "DELETE")
    ),
)

REQUIRED_TABLES = REQUIRED_V1_TABLES | {
    "source_objects", "event_streams", "events", "legacy_source_files", "legacy_event_refs", "event_search_fts",
}
REQUIRED_TRIGGERS = REQUIRED_V1_TRIGGERS | {"event_search_insert"} | {
    f"{table}_immutable_{action}" for table in
    ("source_objects", "event_streams", "events", "legacy_source_files", "legacy_event_refs")
    for action in ("update", "delete")
}
