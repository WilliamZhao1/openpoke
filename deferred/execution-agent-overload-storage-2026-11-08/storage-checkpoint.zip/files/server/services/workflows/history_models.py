"""Immutable captured sources, event envelopes, and exact legacy locators."""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import PurePosixPath, PureWindowsPath
import re
from typing import Optional
from uuid import UUID

from .models import require_text, utc_datetime


class SourceCompleteness(str, Enum):
    COMPLETE = "complete"
    LEGACY_UNKNOWN = "legacy_unknown"
    KNOWN_TRUNCATED = "known_truncated"


def require_integer(value, *, minimum=0):
    if type(value) is not int or not minimum <= value <= 9223372036854775806:
        raise ValueError(f"Expected an integer in SQLite's range, at least {minimum}")
    return value


def require_sha256(value):
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError("Expected a lowercase SHA-256 fingerprint")
    return value


def require_source_path(value):
    require_text(value, nonempty=True)
    path = PurePosixPath(value)
    if (path.is_absolute() or ".." in path.parts or str(path) != value or value == "."
            or "\\" in value or PureWindowsPath(value).drive or "\x00" in value):
        raise ValueError("Legacy source paths must be canonical relative POSIX paths")
    return value


@dataclass(frozen=True)
class SourceInput:
    content: bytes
    media_type: str
    provenance: str
    completeness: SourceCompleteness = SourceCompleteness.COMPLETE

    def __post_init__(self):
        if not isinstance(self.content, bytes):
            raise ValueError("Source content must be immutable bytes")
        require_text(self.media_type, nonempty=True)
        require_text(self.provenance, nonempty=True)
        object.__setattr__(self, "completeness", SourceCompleteness(self.completeness))


@dataclass(frozen=True)
class SourceRecord:
    source_id: UUID
    scope: str
    generation_id: UUID
    content_sha256: str
    size_bytes: int
    media_type: str
    provenance: str
    completeness: SourceCompleteness
    recorded_at: datetime

    def __post_init__(self):
        for field in ("source_id", "generation_id"):
            object.__setattr__(self, field, UUID(str(getattr(self, field))))
        require_text(self.scope, nonempty=True)
        require_sha256(self.content_sha256)
        require_integer(self.size_bytes)
        require_text(self.media_type, nonempty=True)
        require_text(self.provenance, nonempty=True)
        object.__setattr__(self, "completeness", SourceCompleteness(self.completeness))
        object.__setattr__(self, "recorded_at", utc_datetime(self.recorded_at))


@dataclass(frozen=True)
class SourcePage:
    source: SourceRecord
    offset: int
    content: bytes
    next_offset: Optional[int]


@dataclass(frozen=True)
class HistoryEvent:
    event_id: UUID
    source_id: UUID
    scope: str
    generation_id: UUID
    stream_key: str
    sequence: int
    kind: str
    workflow_id: Optional[UUID]
    conversation_id: Optional[str]
    run_id: Optional[str]
    turn_id: Optional[str]
    occurred_at: Optional[datetime]
    recorded_at: datetime

    def __post_init__(self):
        for field in ("event_id", "source_id", "generation_id"):
            object.__setattr__(self, field, UUID(str(getattr(self, field))))
        if self.workflow_id is not None:
            object.__setattr__(self, "workflow_id", UUID(str(self.workflow_id)))
        for field in ("scope", "stream_key", "kind"):
            require_text(getattr(self, field), nonempty=True)
        for field in ("conversation_id", "run_id", "turn_id"):
            value = getattr(self, field)
            if value is not None:
                require_text(value, nonempty=True)
        require_integer(self.sequence)
        object.__setattr__(self, "recorded_at", utc_datetime(self.recorded_at))
        if self.occurred_at is not None:
            object.__setattr__(self, "occurred_at", utc_datetime(self.occurred_at))


@dataclass(frozen=True)
class LegacyLocator:
    source_path: str
    source_sha256: str
    legacy_index: int
    line: int
    byte_offset: int
    byte_length: int
    timestamp_text: Optional[str] = None

    def __post_init__(self):
        require_source_path(self.source_path)
        require_sha256(self.source_sha256)
        for field in ("legacy_index", "byte_offset"):
            require_integer(getattr(self, field))
        for field in ("line", "byte_length"):
            require_integer(getattr(self, field), minimum=1)
        if self.timestamp_text is not None:
            require_text(self.timestamp_text)


@dataclass(frozen=True)
class LegacyEventReference:
    locator: LegacyLocator
    event_id: UUID
    raw_source_id: UUID
    scope: str
    generation_id: UUID

    def __post_init__(self):
        for field in ("event_id", "raw_source_id", "generation_id"):
            object.__setattr__(self, field, UUID(str(getattr(self, field))))
        require_text(self.scope, nonempty=True)
