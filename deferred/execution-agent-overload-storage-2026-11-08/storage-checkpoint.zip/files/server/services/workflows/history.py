"""Source/event persistence primitives; no legacy-file reader or live adapter."""

from dataclasses import asdict
from hashlib import sha256
import json
from uuid import UUID, uuid4

from .errors import WorkflowConflictError, WorkflowIntegrityError
from .history_models import (
    HistoryEvent, LegacyEventReference, LegacyLocator, SourceCompleteness,
    SourceInput, SourcePage, SourceRecord, require_integer, require_source_path,
)
from .models import decode_timestamp, encode_timestamp, require_text


EVENT_SELECT = """SELECT e.*, s.workflow_id, s.conversation_id FROM events e JOIN event_streams s
    ON e.scope=s.scope AND e.generation_id=s.generation_id AND e.stream_key=s.stream_key"""
SOURCE_COLUMNS = "source_id, scope, generation_id, content_sha256, size_bytes, media_type, provenance, completeness, recorded_at"


def _digest(value):
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _source_fields(source):
    return {"content_sha256": sha256(source.content).hexdigest(), "size_bytes": len(source.content),
            "media_type": source.media_type, "provenance": source.provenance, "completeness": source.completeness.value}


class WorkflowHistoryStore:
    """Use through WorkflowStore.history to share schema, generation and locks."""

    def __init__(self, store):
        self._store = store

    @staticmethod
    def _event(row):
        try:
            return HistoryEvent(
                event_id=row["event_id"], source_id=row["source_id"], scope=row["scope"],
                generation_id=row["generation_id"], stream_key=row["stream_key"], sequence=row["sequence"],
                kind=row["kind"], workflow_id=row["workflow_id"], conversation_id=row["conversation_id"],
                run_id=row["run_id"], turn_id=row["turn_id"],
                occurred_at=decode_timestamp(row["occurred_at"]) if row["occurred_at"] is not None else None,
                recorded_at=decode_timestamp(row["recorded_at"]),
            )
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            raise WorkflowIntegrityError("Stored event data is invalid") from exc

    @staticmethod
    def _source(row):
        try:
            fields = {name: row[name] for name in SOURCE_COLUMNS.split(", ")}
            fields["recorded_at"] = decode_timestamp(fields["recorded_at"])
            return SourceRecord(**fields)
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            raise WorkflowIntegrityError("Stored source metadata is invalid") from exc

    def _insert_source(self, connection, scope, source, timestamp, fields):
        identifier = str(uuid4())
        connection.execute("""INSERT INTO source_objects
            (source_id, scope, generation_id, content, content_sha256, size_bytes, media_type, provenance, completeness, recorded_at)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (identifier, scope, str(self._store.generation_id), source.content, fields["content_sha256"], fields["size_bytes"],
             source.media_type, source.provenance, source.completeness.value, timestamp))
        return identifier

    def append_event(self, *, scope, stream_key, kind, source, idempotency_key,
                     workflow_id=None, conversation_id=None, run_id=None, turn_id=None,
                     occurred_at=None, search_text=""):
        """Capture exact supplied bytes and an event in one transaction.

        Keys are backend-owned capture identities, not email-send deduplication.
        """
        require_text(idempotency_key, nonempty=True)
        return self._append(scope=scope, stream_key=stream_key, kind=kind, source=source,
                            write_key="capture:" + idempotency_key, workflow_id=workflow_id,
                            conversation_id=conversation_id, run_id=run_id, turn_id=turn_id,
                            occurred_at=occurred_at, search_text=search_text)

    def append_legacy_event(self, *, scope, stream_key, kind, source, locator, raw_record,
                            workflow_id=None, conversation_id=None, search_text=""):
        """Persistence only: caller must reconcile ownership and verify the frozen file.

        One path is bound to one fingerprint per scope/generation. Changed inputs
        require reconciliation, not a new set of silently duplicated events.
        """
        if not isinstance(locator, LegacyLocator) or not isinstance(source, SourceInput):
            raise ValueError("Legacy capture requires a validated source and locator")
        if not isinstance(raw_record, bytes) or len(raw_record) != locator.byte_length:
            raise ValueError("Raw legacy record length must match its locator")
        if source.completeness == SourceCompleteness.COMPLETE:
            raise ValueError("Legacy payload completeness must be explicitly qualified")
        return self._append(scope=scope, stream_key=stream_key, kind=kind, source=source,
                            write_key="legacy:" + _digest([locator.source_path, locator.legacy_index]),
                            workflow_id=workflow_id, conversation_id=conversation_id,
                            search_text=search_text, locator=locator, raw_record=raw_record)

    def _append(self, *, scope, stream_key, kind, source, write_key, workflow_id=None,
                conversation_id=None, run_id=None, turn_id=None, occurred_at=None,
                search_text="", locator=None, raw_record=None):
        for value in (scope, stream_key, kind):
            require_text(value, nonempty=True)
        require_text(search_text)
        if not isinstance(source, SourceInput):
            raise ValueError("Event capture requires a validated SourceInput")
        for value in (conversation_id, run_id, turn_id):
            if value is not None:
                require_text(value, nonempty=True)
        workflow = str(UUID(str(workflow_id))) if workflow_id is not None else None
        occurred = encode_timestamp(occurred_at) if occurred_at is not None else None
        # Hash potentially large objects before taking SQLite's writer lock.
        source_fields = _source_fields(source)
        raw_source = SourceInput(raw_record, "application/octet-stream", "legacy_raw_record") if locator else None
        raw_fields = _source_fields(raw_source) if raw_source is not None else None
        request_hash = _digest({"stream_key": stream_key, "kind": kind, "source": source_fields,
                                "workflow_id": workflow, "conversation_id": conversation_id,
                                "run_id": run_id, "turn_id": turn_id, "occurred_at": occurred,
                                "search_text": search_text, "locator": asdict(locator) if locator else None,
                                "raw_sha256": raw_fields["content_sha256"] if raw_fields is not None else None})
        with self._store._transaction(write=True) as connection:
            generation = str(self._store.generation_id)
            existing = connection.execute(EVENT_SELECT + " WHERE e.scope=? AND e.generation_id=? AND e.write_key=?",
                                          (scope, generation, write_key)).fetchone()
            if existing is not None:
                if existing["request_sha256"] != request_hash:
                    raise WorkflowConflictError("Event capture identity was reused with different content or bindings")
                if locator and connection.execute("SELECT 1 FROM legacy_event_refs WHERE event_id=?", (existing["event_id"],)).fetchone() is None:
                    raise WorkflowIntegrityError("Legacy event mapping is missing")
                return self._event(existing)
            stamp = encode_timestamp(self._store._clock())
            if workflow is not None:
                self._store._required(connection, workflow, scope)
            stream = connection.execute("SELECT workflow_id, conversation_id FROM event_streams WHERE scope=? AND generation_id=? AND stream_key=?",
                                        (scope, generation, stream_key)).fetchone()
            if stream is None:
                connection.execute("INSERT INTO event_streams VALUES(?, ?, ?, ?, ?, ?)",
                                   (stream_key, scope, generation, workflow, conversation_id, stamp))
            elif (stream["workflow_id"], stream["conversation_id"]) != (workflow, conversation_id):
                raise WorkflowConflictError("Event stream is already bound to a different owner")
            if locator:
                original = connection.execute("SELECT source_sha256, stream_key FROM legacy_source_files WHERE scope=? AND generation_id=? AND source_path=?",
                                              (scope, generation, locator.source_path)).fetchone()
                if original is None:
                    connection.execute("INSERT INTO legacy_source_files VALUES(?, ?, ?, ?, ?, ?)",
                                       (scope, generation, locator.source_path, locator.source_sha256, stream_key, stamp))
                elif (original["source_sha256"], original["stream_key"]) != (locator.source_sha256, stream_key):
                    raise WorkflowConflictError("Legacy source fingerprint or stream changed; reconcile the migration input")
            source_id = self._insert_source(connection, scope, source, stamp, source_fields)
            raw_id = None
            if locator:
                raw_id = self._insert_source(connection, scope, raw_source, stamp, raw_fields)
            sequence = connection.execute("SELECT COALESCE(MAX(sequence), -1) + 1 FROM events WHERE scope=? AND generation_id=? AND stream_key=?",
                                          (scope, generation, stream_key)).fetchone()[0]
            event_id = str(uuid4())
            connection.execute("""INSERT INTO events(event_id, scope, generation_id, stream_key, sequence, kind,
                source_id, run_id, turn_id, occurred_at, recorded_at, write_key, request_sha256, search_text)
                VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (event_id, scope, generation, stream_key, sequence, kind, source_id, run_id, turn_id,
                 occurred, stamp, write_key, request_hash, search_text))
            if locator:
                connection.execute("INSERT INTO legacy_event_refs VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                   (scope, generation, locator.source_path, locator.legacy_index, event_id, raw_id,
                                    locator.line, locator.byte_offset, locator.byte_length, locator.timestamp_text))
            return self._event(connection.execute(EVENT_SELECT + " WHERE e.event_id=?", (event_id,)).fetchone())

    def get_event(self, event_id, *, scope):
        identifier = str(UUID(str(event_id)))
        require_text(scope, nonempty=True)
        with self._store._transaction() as connection:
            row = connection.execute(EVENT_SELECT + " WHERE e.event_id=? AND e.scope=? AND e.generation_id=?",
                                     (identifier, scope, str(self._store.generation_id))).fetchone()
            return self._event(row) if row is not None else None

    def list_events(self, *, scope, stream_key, limit=20, after_sequence=-1):
        require_text(scope, nonempty=True)
        require_text(stream_key, nonempty=True)
        require_integer(limit, minimum=1)
        require_integer(after_sequence, minimum=-1)
        if limit > 100:
            raise ValueError("Event page limit must be at most 100")
        with self._store._transaction() as connection:
            rows = connection.execute(EVENT_SELECT + " WHERE e.scope=? AND e.generation_id=? AND e.stream_key=? AND e.sequence>? ORDER BY e.sequence LIMIT ?",
                                      (scope, str(self._store.generation_id), stream_key, after_sequence, limit)).fetchall()
            return [self._event(row) for row in rows]

    def get_source(self, source_id, *, scope):
        identifier = str(UUID(str(source_id)))
        require_text(scope, nonempty=True)
        with self._store._transaction() as connection:
            row = connection.execute(f"SELECT {SOURCE_COLUMNS} FROM source_objects WHERE source_id=? AND scope=? AND generation_id=?",
                                     (identifier, scope, str(self._store.generation_id))).fetchone()
            return self._source(row) if row is not None else None

    def read_source(self, source_id, *, scope, offset=0, limit=8192):
        """Byte pages, never previews or Unicode-sliced approximations of content."""
        identifier = str(UUID(str(source_id)))
        require_text(scope, nonempty=True)
        require_integer(offset)
        require_integer(limit, minimum=1)
        if limit > 65536:
            raise ValueError("Source page limit must be at most 65536 bytes")
        with self._store._transaction() as connection:
            # SQLite substr(empty_blob, ...) returns NULL, not an empty BLOB.
            row = connection.execute(f"SELECT {SOURCE_COLUMNS}, CASE WHEN size_bytes=0 THEN content ELSE substr(content, ?, ?) END AS page FROM source_objects WHERE source_id=? AND scope=? AND generation_id=?",
                                     (offset + 1, limit, identifier, scope, str(self._store.generation_id))).fetchone()
            if row is None:
                return None
            source = self._source(row)
            if offset > source.size_bytes:
                raise ValueError("Source offset exceeds content length")
            content = row["page"]
            if not isinstance(content, bytes) or len(content) != min(limit, source.size_bytes - offset):
                raise WorkflowIntegrityError("Stored source page is invalid")
            following = offset + len(content)
            return SourcePage(source, offset, content, following if following < source.size_bytes else None)

    def resolve_legacy(self, source_path, legacy_index, *, scope):
        require_source_path(source_path)
        require_integer(legacy_index)
        require_text(scope, nonempty=True)
        with self._store._transaction() as connection:
            row = connection.execute("""SELECT r.*, f.source_sha256 FROM legacy_event_refs r JOIN legacy_source_files f
                ON r.scope=f.scope AND r.generation_id=f.generation_id AND r.source_path=f.source_path
                WHERE r.scope=? AND r.generation_id=? AND r.source_path=? AND r.legacy_index=?""",
                (scope, str(self._store.generation_id), source_path, legacy_index)).fetchone()
            if row is None:
                return None
            try:
                locator = LegacyLocator(**{name: row[name] for name in LegacyLocator.__dataclass_fields__})
                return LegacyEventReference(locator, row["event_id"], row["raw_source_id"], scope, self._store.generation_id)
            except (ValueError, TypeError, KeyError, AttributeError) as exc:
                raise WorkflowIntegrityError("Stored legacy mapping is invalid") from exc

    def rebuild_event_index(self):
        with self._store._transaction(write=True) as connection:
            connection.execute("INSERT INTO event_search_fts(event_search_fts) VALUES('rebuild')")
            return connection.execute("SELECT COUNT(*) FROM events WHERE generation_id=?", (str(self._store.generation_id),)).fetchone()[0]
